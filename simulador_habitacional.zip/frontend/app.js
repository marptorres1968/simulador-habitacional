
document.getElementById("root").innerHTML = "<h2>Simulador carregado. Interface aqui.</h2>";
